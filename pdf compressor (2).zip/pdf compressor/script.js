// PROPER PDFLib initialization
const { PDFDocument } = PDFLib;

// Initialize PDF.js
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.11.338/pdf.worker.min.js';

let pdfDoc = null;
let originalSize = 0;
let compressedPdfBlob = null;

// DOM elements
const fileInput = document.getElementById('pdf-file');
const dropZone = document.getElementById('drop-zone');
const previewContainer = document.getElementById('pdf-preview');
const statusEl = document.getElementById('status');
const originalSizeEl = document.getElementById('original-size');
const compressedSizeEl = document.getElementById('compressed-size');
const reductionEl = document.getElementById('reduction');
const compressBtn = document.getElementById('compress-btn');
const downloadBtn = document.getElementById('download-btn');
const compressionLevel = document.getElementById('compression-level');
const imageQualitySlider = document.getElementById('image-quality');
const qualityValue = document.getElementById('quality-value');

// Event listeners
fileInput.addEventListener('change', handleFileUpload);
dropZone.addEventListener('click', () => fileInput.click());
dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.style.background = '#f0f4ff';
});
dropZone.addEventListener('dragleave', () => {
    dropZone.style.background = '';
});
dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.style.background = '';
    if (e.dataTransfer.files.length) {
        fileInput.files = e.dataTransfer.files;
        handleFileUpload({ target: fileInput });
    }
});
compressBtn.addEventListener('click', compressPDF);
downloadBtn.addEventListener('click', downloadCompressedPDF);
imageQualitySlider.addEventListener('input', updateQualityValue);

// Update image quality display
function updateQualityValue() {
    qualityValue.textContent = `${imageQualitySlider.value}%`;
}

// Handle PDF upload
async function handleFileUpload(e) {
    const file = e.target.files[0];
    if (!file) return;

    statusEl.textContent = "Loading PDF...";
    statusEl.className = '';
    previewContainer.innerHTML = '';
    compressBtn.disabled = true;
    downloadBtn.disabled = true;
    originalSize = file.size;
    originalSizeEl.textContent = formatFileSize(originalSize);
    compressedSizeEl.textContent = '-';
    reductionEl.textContent = '-';

    try {
        // Load with PDF.js for preview
        const arrayBuffer = await file.arrayBuffer();
        pdfDoc = await pdfjsLib.getDocument(arrayBuffer).promise;

        // Render first page preview
        const page = await pdfDoc.getPage(1);
        const viewport = page.getViewport({ scale: 0.5 });

        const thumbnail = document.createElement('div');
        thumbnail.className = 'page-thumbnail';
        thumbnail.style.width = `${viewport.width}px`;

        const canvas = document.createElement('canvas');
        canvas.height = viewport.height;
        canvas.width = viewport.width;

        const pageNum = document.createElement('div');
        pageNum.className = 'page-number';
        pageNum.textContent = `Page 1 of ${pdfDoc.numPages}`;

        thumbnail.appendChild(pageNum);
        thumbnail.appendChild(canvas);
        previewContainer.appendChild(thumbnail);

        await page.render({
            canvasContext: canvas.getContext('2d'),
            viewport: viewport
        }).promise;

        statusEl.textContent = `Ready to compress! (${pdfDoc.numPages} pages)`;
        compressBtn.disabled = false;

    } catch (error) {
        showError(`Error loading PDF: ${error.message}`);
    }
}

// Compress PDF - SIMPLIFIED VERSION THAT WORKS
async function compressPDF() {
    if (!pdfDoc) {
        showError("No PDF loaded!");
        return;
    }

    statusEl.textContent = "Compressing PDF...";
    statusEl.className = '';
    compressBtn.disabled = true;

    try {
        const file = fileInput.files[0];
        const arrayBuffer = await file.arrayBuffer();
        
        // Load the PDF document
        const pdfDoc = await PDFDocument.load(arrayBuffer);
        
        // Set save options for compression
        const saveOptions = {
            useObjectStreams: true,  // Enables compression
            useCompression: true    // Compresses the PDF
        };
        
        // Save with compression
        const pdfBytes = await pdfDoc.save(saveOptions);
        const compressedSize = pdfBytes.byteLength;
        
        // Update UI
        compressedSizeEl.textContent = formatFileSize(compressedSize);
        const reduction = ((originalSize - compressedSize) / originalSize * 100).toFixed(1);
        reductionEl.textContent = `${reduction}% smaller`;
        
        // Create download link
        compressedPdfBlob = new Blob([pdfBytes], { type: 'application/pdf' });
        downloadBtn.disabled = false;
        
        statusEl.textContent = `Compression complete! Saved ${reduction}%`;
        
    } catch (error) {
        showError(`Error compressing PDF: ${error.message}`);
        compressBtn.disabled = false;
    }
}

// Download compressed PDF
function downloadCompressedPDF() {
    if (!compressedPdfBlob) return;
    
    const url = URL.createObjectURL(compressedPdfBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `compressed_${fileInput.files[0].name}`;
    a.click();
    URL.revokeObjectURL(url);
}

// Helper functions
function formatFileSize(bytes) {
    if (bytes < 1024) return bytes + ' bytes';
    else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    else return (bytes / 1048576).toFixed(1) + ' MB';
}

function showError(message) {
    statusEl.textContent = message;
    statusEl.className = 'error';
    console.error(message);
}